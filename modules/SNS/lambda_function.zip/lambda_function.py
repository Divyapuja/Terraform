import boto3

def lambda_handler(event, context):
    client = boto3.client('stepfunctions')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:070976655252:stateMachine:SMforPython2'
    )