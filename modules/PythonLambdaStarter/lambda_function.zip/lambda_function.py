import boto3
import botocore
import json
import time

def moveFunction_handler(event, context):
    # Get the service resource
    s3 = boto3.resource('s3')
    sqs = boto3.resource('sqs')
    client = boto3.client('ssm')
    destQueue = boto3.client('sqs')
    destBucket = client.get_parameter(Name='destBucket')['Parameter']['Value']

    # Sanity check
    if destBucket == None :
        return "Destination Bucket not provided"
    # Get the queue
    #This function sometime may require more than 3 sec so increase the time if required
    queue = sqs.get_queue_by_name(QueueName='SNS-SQS')
    SuccessQueue = sqs.get_queue_by_name(QueueName='SuccessQueue')
    FailQueue = sqs.get_queue_by_name(QueueName='FailQueue')
    for message in queue.receive_messages():
        result = format(message.body)
        key = (json.loads(json.loads(result)['Message']))['Records'][0]['s3']['object']['key']
        srcbucket = (json.loads(json.loads(result)['Message']))['Records'][0]['s3']['bucket']['name']
    	copy_source = {
    	    'Bucket': srcbucket,
    		'Key': key
    	}
    	try:
    	    s3.meta.client.copy(copy_source, destBucket, key)
            s3.Object(destBucket, key).load()
            s3.Object(srcbucket, key).delete()
            #copy msg to success Queue
            SuccessQueue.send_message(QueueUrl=destQueue.get_queue_url(QueueName='SuccessQueue')['QueueUrl'],MessageBody=message.body)
        except :
            #copy msg to Failure Queue
            FailQueue.send_message(QueueUrl=destQueue.get_queue_url(QueueName='FailQueue')['QueueUrl'],MessageBody=message.body)
        message.delete()
        
